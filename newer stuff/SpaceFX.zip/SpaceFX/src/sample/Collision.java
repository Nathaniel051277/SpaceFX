package sample;

// Used by Christian C.
// Base of Lab 7 pdf

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Collision { // Simple collision detection code
    private Timer MainTimer;
    private Player player;
    private Enemy enemy;
    private Heart[] heart;

    public void Starter(Player player, Enemy enemy, Heart[] hearts){
        this.player = player;
        this.enemy = enemy;
        this.heart = hearts;

        MainTimer = new Timer(100, new TimeHandler());
        MainTimer.start();
    }

    public boolean checkCollision(int r1TopLeftX, int
            r1BottomRightX,int r1TopLeftY, int r1BottomRightY, int
                                              r2TopLeftX,int r2BottomRightX, int r2TopLeftY, int
                                              r2BottomRightY)
    {
        return r1TopLeftX < r2BottomRightX && r1BottomRightX >
                r2TopLeftX && r1TopLeftY < r2BottomRightY && r1BottomRightY >
                r2TopLeftY;
    }

    public void StopTimer(){

        MainTimer.stop(); // Stop timer

    }


    private  class TimeHandler implements ActionListener { // Timer Listener
        @Override
        public void actionPerformed(ActionEvent e) { // Timer for checking if the player has hit the Enemy or not
            if(checkCollision(player.getX(), player.getX() + 150, player.getY(), player.getY() + 110,
                    enemy.getX(), enemy.getX() + 150, enemy.getY(), enemy.getY() + 110)){
               // System.out.println("True");
                player.chnageKey(true);
            }
            for(int i = 0; i < heart.length; i++) { // For loop to check if the heart as been hit
                if (checkCollision(player.getX(), player.getX() + 150, player.getY(), player.getY() + 110, //  Check for player
                        heart[i].getX(), heart[i].getX() + 129, heart[i].getY(), heart[i].getY() + 130)) {
                    heart[i].setX(1500); // Set of heath of screen
                    //System.out.println("True H");
                }
                else if(checkCollision(enemy.getX(), enemy.getX() + 150, enemy.getY(), enemy.getY() + 110, // Check for enemy
                        heart[i].getX(), heart[i].getX() + 129, heart[i].getY(), heart[i].getY() + 130)) {
                    heart[i].setX(1500);
                }
            }
            }
        }
    }

